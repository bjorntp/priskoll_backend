package com.bjorntp.systemet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemetApplication.class, args);
	}

}
